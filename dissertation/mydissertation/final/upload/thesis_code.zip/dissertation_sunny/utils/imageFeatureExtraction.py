import numpy as np


# transform array to seperatted array through list
# arr  ---input
def extractTimeImage(list_arr, list1_arr, list2_arr, list3_arr, list4_arr, list5_arr, arr):
    for i in range(len(arr)):
        list_arr.append((arr[i]).tolist())
        list1_arr.append(list_arr[i][0])
        list2_arr.append(list_arr[i][1])
        list3_arr.append(list_arr[i][2])
        list4_arr.append(list_arr[i][3])
        list5_arr.append(list_arr[i][4])

    list1_arr = np.array(list1_arr)
    list2_arr = np.array(list2_arr)
    list3_arr = np.array(list3_arr)
    list4_arr = np.array(list4_arr)
    list5_arr = np.array(list5_arr)
    return list1_arr, list2_arr, list3_arr, list4_arr, list5_arr
