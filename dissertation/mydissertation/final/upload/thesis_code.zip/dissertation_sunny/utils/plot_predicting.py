import matplotlib.pyplot as plt

#plot_results_predicting
def plot_results_multiple(predicted_data, true_data):
    fig = plt.figure(facecolor='white')
    ax = fig.add_subplot(111)
    ax.plot(true_data,'r', label='True Data')
    ax.plot(predicted_data,'b', label='predicted_data')
    plt.legend()
    plt.savefig('results_predicting.png')
