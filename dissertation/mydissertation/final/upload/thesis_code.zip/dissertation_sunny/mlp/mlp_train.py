from math import sqrt
from matplotlib import pyplot
import pandas as pd
from numpy import concatenate
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error,mean_absolute_error
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation
from sklearn.model_selection import train_test_split
import data_preprocessing
from utils import plot_predicting
from keras.utils import plot_model
from keras.callbacks import EarlyStopping


filepath = '../pvData/'
saved_filename = "../processed_data/data.txt"

data_preprocessing.text_save(filepath,saved_filename)

# read data
train_df = pd.read_csv(saved_filename,delim_whitespace=True, header=None)


# df transform into array
values = train_df.values
# Normalization of raw data in order to accelerate convergence
scaler = MinMaxScaler(feature_range=(0, 1))
scaled = scaler.fit_transform(values)
y = scaled[:, -1]
X = scaled[:, 0:-1]

# Randomly split training set and test set
train_X, test_X, train_y, test_y = train_test_split(X, y, test_size=0.25,random_state=42)

input = X.shape[1]


def build(input):
    model = Sequential()

    model.add(Dense(64, input_shape=(input,)))
    model.add(Activation('relu'))
    model.add(Dense(64))
    model.add(Dropout(0.5))
    model.add(Dense(1,activation='sigmoid'))
    return model

model=build(input)

#plot model
plot_model(model, to_file='mlp_model.png', show_shapes=True)

model.compile(loss='mean_squared_error', optimizer='adam')

early_stopping = EarlyStopping(monitor='val_loss', patience=50, verbose=2)
# 训练

H = model.fit(train_X, train_y, epochs=120, batch_size=32,
                    validation_data=(test_X, test_y), verbose=2,
                    shuffle=False)

# loss
pyplot.style.use("ggplot")
pyplot.figure()
pyplot.plot(H.history['loss'], label='train')
pyplot.plot(H.history['val_loss'], label='test')
pyplot.title("Training Loss and Accuracy (NN)")

pyplot.legend()
pyplot.show()

# predoction
yhat = model.predict(test_X)
#Prediction y inverse normalization
inv_yhat0 = concatenate((test_X, yhat), axis=1)
inv_yhat1 = scaler.inverse_transform(inv_yhat0)
inv_yhat = inv_yhat1[:, -1]

# Original y inverse normalization
test_y = test_y.reshape(len(test_y), 1)
inv_y0 = concatenate((test_X, test_y), axis=1)
inv_y1 = scaler.inverse_transform(inv_y0)
inv_y = inv_y1[:, -1]

#plot predicting
plot_predicting.plot_results_multiple(inv_yhat,inv_y)

#MAE
mae=mean_absolute_error(inv_y, inv_yhat)
print('Test MAE: %.3f' % mae)
pyplot.plot(inv_y)
pyplot.plot(inv_yhat)
pyplot.show()

# RMSE
rmse = sqrt(mean_squared_error(inv_y, inv_yhat))
print('Test RMSE: %.3f' % rmse)
pyplot.plot(inv_y)
pyplot.plot(inv_yhat)
pyplot.show()
