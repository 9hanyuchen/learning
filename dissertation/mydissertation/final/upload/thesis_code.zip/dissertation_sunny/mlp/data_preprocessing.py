import os
import numpy as np



def text_save(filepath, saved_filename):  # filename is the path to write the CSV file, and data is the list of data to be written.
    pathDir = os.listdir(filepath)

    while '.DS_Store' in pathDir:
        pathDir.remove('.DS_Store')

    for j in range(len(pathDir)):

        Efield = []

        newfilepath = filepath + pathDir[j]
        print(newfilepath)
        with open(newfilepath, 'r') as file_to_read:
            while True:
                lines = file_to_read.readline()  # read lines
                if not lines:
                    break
                    pass

                E_tmp = float(lines.split(",  ")[1])

                Efield.append(E_tmp)
                pass

        pass

        Efield1 = Efield[5740:11500]    #choose the data from 08:00-17:00 roughly
        Efield1 = np.array(Efield1)

        # Find the average pv per minute
        count = 0
        list1 = []  # get mean
        total_list = []
        # Get every data in txt
        for i in range(len(Efield1)):

            count += 1
            list1.append(Efield1[i])

            if (count % 12 == 0):
                mean_value = np.mean(list1)
                mean_value = round(mean_value, 2)
                total_list.append(mean_value)
                list1.clear()

        # input   total_list
        k = 5  # How many minutes pv how many features

        list2 = [list2 for list2 in total_list[0:k]]  # 放入初始的10个value
        print("第 %d 次:%f" %(j,list2[0]))


        file = open(saved_filename, 'a')
        for i in range(k, len(total_list)):
            list2.append(total_list[i])

            s = str(list2).replace('[', '').replace(']', '')  # Remove [], the two rows are different by data
            s = s.replace("'", '').replace(',', '') + '\n'  # Remove single quotes, commas, and append newlines at the end of each line
            file.write(s)

            del (list2[0])
        file.close()
        print("save successfully")


#text_save(filepath, saved_filename)
