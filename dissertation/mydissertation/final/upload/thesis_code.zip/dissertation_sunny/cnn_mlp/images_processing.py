from sklearn.preprocessing import LabelBinarizer
from sklearn.preprocessing import MinMaxScaler
import pandas as pd
import numpy as np
import os
import re
import cv2
from numpy import moveaxis

imagePaths = "../dataset/"
txtPaths = "../pvData/"

#transform a list(array) of images into 1 mult-channel images in gray scale.
def to_grey(imgPathList):
    list = []
    for path in imgPathList:
        img = cv2.imread(path)
        img = cv2.resize(img, (128, 128))
        list.append(img)

    list2 = []
    for i in range(len(list)):
        b, g, r = cv2.split(list[i])
        list2.append(r)

    newImage = np.array(list2)

    newImage = moveaxis(newImage, 2, 1)

    newImage = moveaxis(newImage, 0, 2)

    newImage = moveaxis(newImage, 0, 1)

    newImage = newImage / 255.0   ## range [0, 1]

    return newImage


def image_processing(imagePaths):

    images = [] #initialize our images array

    # 获取第一个imagepath;
    pathDirs = os.listdir(imagePaths)

    while '.DS_Store' in pathDirs:
        pathDirs.remove('.DS_Store')


    for i in range(len(pathDirs)):
        file_names = []  # List all the JPG files you put in on a given day

        # get all files
        newfilepath = imagePaths + pathDirs[i]
        print("newfilepath:%s" %newfilepath)
        # Gets all the files for a given day
        listfiles1=os.listdir(newfilepath)
        listfiles = sorted(listfiles1, key=lambda x: os.path.getmtime(os.path.join(newfilepath, x)))

        #Get only files with.jpg suffix
        for file_name in listfiles:
            if os.path.splitext(file_name)[1] == '.jpg':
                file_names.append(file_name)

        first_images = []
        grey_images = []

        file_names=file_names[0:28800] #get images file

        for j in range(len(file_names)):
            #Every 15 seconds, take the exposure picture of the middle three levels

            if (j % 15 == 1 or j % 15 == 2 or j % 15 == 3):
                print(j)
                imagep=newfilepath+"/"+file_names[j] #Imagep is the path to select a good image for reading
                first_images.append(imagep)

                if(len(first_images)==12): #get 12 images in one minute

                    grey_images.append(to_grey(first_images))

                    first_images.clear()

                    if(len(grey_images)==5): #get 5 minutes of pictures
                        grey_images_val = []
                        for t in range(5):
                            grey_images_val.append(grey_images[i])

                        images.append(grey_images_val)

                        del(grey_images[0])
        del(images[-1])


    return np.array(images)










