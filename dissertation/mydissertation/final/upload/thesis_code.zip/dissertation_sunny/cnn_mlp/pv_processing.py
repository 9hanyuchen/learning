import os
import re
import numpy as np


imagePaths = "../dataset/"
txtPaths="../pvData/"
saved_filename="../processed_data/pvdata.txt"


def pv_processing(imagePaths, txtPaths,saved_filename):
    pathDirs = os.listdir(imagePaths)

    while '.DS_Store' in pathDirs:
        pathDirs.remove('.DS_Store')

    for i in range(len(pathDirs)):
        file_names = [] #List all the JPG files you put in on a given day

        #get all
        newfilepath = imagePaths + pathDirs[i]

        #Gets all the files for a given day
        listfiles1=os.listdir(newfilepath)
        listfiles = sorted(listfiles1, key=lambda x: os.path.getmtime(os.path.join(newfilepath, x)))

        for file_name in listfiles:
            if os.path.splitext(file_name)[1]=='.jpg':
                file_names.append(file_name)

        #Get the time of day when the first picture was taken
        aim_filename=file_names[0]
        m = re.findall(r'(.+?)\_', aim_filename)

        #Process the corresponding TXT file
        pathDir = os.listdir(txtPaths)

        while '__init__.py' in pathDir:
            pathDir.remove('__init__.py')
        print(pathDir)

        Efield1 = []
        Efield2 = []

        txtPath = txtPaths + pathDirs[i]+ ".data"

        print(txtPath)

        with open(txtPath, 'r') as file_to_read:
            while True:
                lines = file_to_read.readline()  # Read the whole line of data
                if not lines:
                    break
                    pass

                E_tmp1 = lines.split(",  ")[0]
                E_tmp2 = float(lines.split(",  ")[1])

                Efield1.append(E_tmp1)
                Efield2.append(E_tmp2)
                pass
        print(m[0])

        print(len(Efield1))
        timeIndex = Efield1.index(m[0])
        print(timeIndex)
        pvalues=Efield2[timeIndex:(timeIndex+5760)] #Pvalue is the pv value of a day from the pv value corresponding to the first picture to 8 hours later (16:00), in the form of list
        #print(pvalues)

        #Get the value value after 1 min
        pvalues = np.array(pvalues)

        # Average pv per minute
        count = 0
        list1 = []  # store the mean
        total_list = []
        # Get each data in TXT
        for i in range(len(pvalues)):
            count += 1
            list1.append(pvalues[i])

            if (count % 12 == 0):
                mean_value = np.mean(list1)
                mean_value = round(mean_value, 2)
                total_list.append(mean_value)
                list1.clear()

        # input   total_list
        k = 5  # How many minutes of pv how many features

        list2 = [list2 for list2 in total_list[0:k]]


        file = open(saved_filename, 'a')
        for i in range(k, len(total_list)):
            list2.append(total_list[i])

            s = str(list2).replace('[', '').replace(']', '')  # Remove [], the two rows are different by data
            s = s.replace("'", '').replace(',', '') + '\n'  # Remove single quotes, commas, and append newlines at the end of each line
            file.write(s)
            del (list2[0])

        file.close()
        print("save successfully")





