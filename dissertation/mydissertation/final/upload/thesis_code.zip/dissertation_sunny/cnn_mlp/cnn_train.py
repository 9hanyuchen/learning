from matplotlib import pyplot
import pandas as pd
import numpy as np
from keras.layers import concatenate
from keras.layers.core import Dense, Dropout, Activation
from sklearn.model_selection import train_test_split
import images_processing
import pv_processing
import models
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error,mean_absolute_error
from keras.models import Model
from keras.optimizers import Adam
from math import sqrt
from utils import imageFeatureExtraction,plot_predicting


from keras.utils import plot_model
import os
import tensorflow as tf
import keras.backend.tensorflow_backend as KTF




os.environ["CUDA_VISIBLE_DEVICES"] = "0,1"

gpu_options = tf.GPUOptions(allow_growth=True)

sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options))


# set session
KTF.set_session(sess )

imagePaths = "../dataset/"
txtPaths = "../pvData/"
saved_filename = "../processed_data/pvdata.txt"

# pv data
print("[INFO] loading pv data...")
pv_processing.pv_processing(imagePaths, txtPaths, saved_filename)

train_df = pd.read_csv(saved_filename, delim_whitespace=True, header=None)

# df transform into array
values = train_df.values
# Normalization of raw data in order to accelerate convergence
scaler = MinMaxScaler(feature_range=(0, 1))
scaled = scaler.fit_transform(values)
x_whole = scaled[:, 0:-1]
mlp_input = x_whole.shape[1]

# image data
print("[INFO] loading images...")
images = images_processing.image_processing(imagePaths)
# images=images/255.0    # range [0, 1]


# partition the data into training and testing splits using 75% of
# the data for training and the remaining 25% for testing
print("[INFO] processing data...")

split = train_test_split(scaled, images, test_size=0.25, random_state=42)
(trainAttrX, testAttrX, trainImagesX, testImagesX) = split

train_X = trainAttrX[:, 0:-1]  # feature
train_y = trainAttrX[:, -1]  # label

test_X = testAttrX[:, 0:-1]
test_y = testAttrX[:, -1]



# create the MLP and CNN models
mlp = models.create_mlp(train_X.shape[1])
cnn1 = models.create_cnn(128, 128, 12)
cnn2 = models.create_cnn(128, 128, 12)
cnn3 = models.create_cnn(128, 128, 12)
cnn4 = models.create_cnn(128, 128, 12)
cnn5 = models.create_cnn(128, 128, 12)

# create the input to our final set of layers as the *output* of both
# the MLP and CNN
combinedInput = concatenate([mlp.output, cnn1.output, cnn2.output, cnn3.output, cnn4.output, cnn5.output])

# our final FC layer head will have two dense layers, the final one
# being our regression head
x = Dense(1024, activation="relu")(combinedInput)
x = Dense(1024, activation="relu")(x)
x = Dense(1, activation='sigmoid')(x)

model = Model(inputs=[mlp.input, cnn1.input, cnn2.input, cnn3.input, cnn4.input, cnn5.input], outputs=x)

plot_model(model, to_file='cnn_model.png', show_shapes=True)

# compile the model using mean absolute percentage error as our loss,
# implying that we seek to minimize the absolute percentage difference
# between our price *predictions* and the *actual prices*
opt = Adam(lr=1e-3, decay=1e-3 / 200)
model.compile(loss="mean_squared_error", optimizer=opt)

# train the model
print("[INFO] training model...")

# extract 5 different times to 1 trainImagesX
print("[INFO] extracting model...")
list_arr = []
trainImagesX_list1 = []
trainImagesX_list2 = []
trainImagesX_list3 = []
trainImagesX_list4 = []
trainImagesX_list5 = []
trainImagesX1, trainImagesX2, trainImagesX3, trainImagesX4, trainImagesX5 = imageFeatureExtraction.extractTimeImage(
    list_arr, trainImagesX_list1, trainImagesX_list2, trainImagesX_list3, trainImagesX_list4, trainImagesX_list5,
    trainImagesX)

# extract 5 different times to 1 testImagesX
list_arr = []
testImagesX_list1 = []
testImagesX_list2 = []
testImagesX_list3 = []
testImagesX_list4 = []
testImagesX_list5 = []
testImagesX1, testImagesX2, testImagesX3, testImagesX4, testImagesX5 = imageFeatureExtraction.extractTimeImage(list_arr,
                                                                                                               testImagesX_list1,
                                                                                                               testImagesX_list2,
                                                                                                               testImagesX_list3,
                                                                                                               testImagesX_list4,
                                                                                                               testImagesX_list5,
                                                                                                               testImagesX)

H = model.fit(
    [train_X, trainImagesX1, trainImagesX2, trainImagesX3, trainImagesX4, trainImagesX5], train_y,
    validation_data=([test_X, testImagesX1, testImagesX2, testImagesX3, testImagesX4, testImagesX5], test_y),
    epochs=120, batch_size=32)

# loss
pyplot.style.use("ggplot")
pyplot.figure()
pyplot.plot(H.history['loss'], label='train')
pyplot.plot(H.history['val_loss'], label='test')
pyplot.title("Training Loss and Accuracy (NN)")

pyplot.legend()
pyplot.show()

# prediction
yhat = model.predict([test_X, testImagesX1, testImagesX2, testImagesX3, testImagesX4, testImagesX5])
# Predict y inverse normalization
inv_yhat0 = np.concatenate((test_X, yhat), axis=1)
inv_yhat1 = scaler.inverse_transform(inv_yhat0)
inv_yhat = inv_yhat1[:, -1]

# Original y inverse normalization
test_y = test_y.reshape(len(test_y), 1)
inv_y0 = np.concatenate((test_X, test_y), axis=1)
inv_y1 = scaler.inverse_transform(inv_y0)
inv_y = inv_y1[:, -1]

#plot predicting
plot_predicting.plot_results_multiple(inv_yhat,inv_y)


#MAE
mae=mean_absolute_error(inv_y, inv_yhat)
print('Test MAE: %.3f' % mae)
pyplot.plot(inv_y)
pyplot.plot(inv_yhat)
pyplot.show()

# RMSE
rmse = sqrt(mean_squared_error(inv_y, inv_yhat))
print('Test RMSE: %.3f' % rmse)
pyplot.plot(inv_y)
pyplot.plot(inv_yhat)
pyplot.show()
